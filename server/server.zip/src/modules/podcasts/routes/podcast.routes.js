import express from "express";
import {
  createEpisode,
  createPodcast,
  deletePodcast,
  getPodcast,
  listEpisodes,
  listPodcasts,
  updatePodcast,
} from "../controllers/podcast.controller.js";
import { authenticate } from "../../../shared/middleware.js";
import upload from "../../../shared/upload.js";
import { validateEpisode, validatePodcast } from "../../../shared/validate.js";

const router = express.Router();

router.get("/", listPodcasts);
router.get("/:id", getPodcast);
router.post(
  "/",
  authenticate,
  upload.single("thumbnail"),
  validatePodcast,
  createPodcast,
);
router.put("/:id", authenticate, validatePodcast, updatePodcast);
router.delete("/:id", authenticate, deletePodcast);
router.post(
  "/:id/episodes",
  authenticate,
  upload.single("audio"),
  validateEpisode,
  createEpisode,
);
router.get("/:id/episodes", listEpisodes);

export default router;

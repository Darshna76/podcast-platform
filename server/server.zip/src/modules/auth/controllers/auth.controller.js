import { authService } from "../auth.service.js";
import { slugify } from "../../../shared/utils.js";

export const register = async (req, res, next) => {
  try {
    const user = await authService.register(req.body);
    res.status(201).json({ user });
  } catch (error) {
    next(error);
  }
};

export const login = async (req, res, next) => {
  try {
    const payload = await authService.login(req.body);
    res.json(payload);
  } catch (error) {
    next(error);
  }
};

export const refresh = async (req, res, next) => {
  try {
    const payload = await authService.refreshToken(req.body.refreshToken);
    res.json(payload);
  } catch (error) {
    next(error);
  }
};

export const logout = async (req, res, next) => {
  try {
    const payload = await authService.logout(req.body.refreshToken);
    res.json(payload);
  } catch (error) {
    next(error);
  }
};

export const me = async (req, res, next) => {
  try {
    res.json({ user: req.user });
  } catch (error) {
    next(error);
  }
};
